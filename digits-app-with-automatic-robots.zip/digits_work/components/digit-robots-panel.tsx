'use client';

import { useEffect, useRef, useState } from 'react';
import type { Tick } from '../lib/types';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Bot, CheckCircle2, XCircle, Play, Square } from 'lucide-react';

type RobotResult = { wins: number; losses: number; last: 'WIN' | 'LOSS' | null };
type RobotName = 'mafs' | 'pares';

function RobotCard({ name, description, digits, lastDigit, result }: { name: string; description: string; digits: number[]; lastDigit: number | null; result: RobotResult }) {
  const qualifies = lastDigit !== null && digits.includes(lastDigit);
  return (
    <Card className="border-border/80 bg-card">
      <CardHeader className="pb-2">
        <CardTitle className="flex items-center justify-between text-base">
          <span className="flex items-center gap-2"><Bot className="h-4 w-4 text-primary" />{name}</span>
          <Badge variant={qualifies ? 'default' : 'secondary'}>{qualifies ? 'SINAL ATIVO' : 'A AGUARDAR'}</Badge>
        </CardTitle>
        <p className="text-xs text-muted-foreground">{description}</p>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="flex flex-wrap gap-1.5">
          {digits.map((digit) => <span key={digit} className={`flex h-7 w-7 items-center justify-center rounded-md text-xs font-bold ${lastDigit === digit ? 'bg-primary text-primary-foreground' : 'bg-muted text-muted-foreground'}`}>{digit}</span>)}
        </div>
        <div className="grid grid-cols-2 gap-2">
          <div className="rounded-lg bg-emerald-500/10 p-2"><div className="flex items-center gap-1 text-xs text-emerald-600"><CheckCircle2 className="h-3.5 w-3.5" /> WINS</div><div className="text-xl font-bold tabular-nums">{result.wins}</div></div>
          <div className="rounded-lg bg-red-500/10 p-2"><div className="flex items-center gap-1 text-xs text-red-500"><XCircle className="h-3.5 w-3.5" /> LOSS</div><div className="text-xl font-bold tabular-nums">{result.losses}</div></div>
        </div>
        <p className="text-xs text-muted-foreground">Último resultado do sinal: <span className="font-semibold">{result.last ?? '—'}</span></p>
      </CardContent>
    </Card>
  );
}

export function DigitRobotsPanel({
  lastDigit,
  currentTick,
  autoBuyMafs,
  autoBuyPares,
  isConnected,
  isAuthenticated,
  isDemoAccount,
  disabled = false,
}: {
  lastDigit: number | null;
  currentTick: Tick | null;
  autoBuyMafs: () => Promise<boolean>;
  autoBuyPares: () => Promise<boolean>;
  isConnected: boolean;
  isAuthenticated: boolean;
  isDemoAccount: boolean;
  disabled?: boolean;
}) {
  const [mafs, setMafs] = useState<RobotResult>({ wins: 0, losses: 0, last: null });
  const [pares, setPares] = useState<RobotResult>({ wins: 0, losses: 0, last: null });
  const [running, setRunning] = useState(false);
  const runningRef = useRef(false);
  const [status, setStatus] = useState('Robôs desligados.');
  const previousTick = useRef<number | null>(null);
  const pendingSignal = useRef<RobotName[]>([]);
  const busy = useRef(false);

  useEffect(() => {
    if (!currentTick || lastDigit === null) return;
    const tickId = currentTick.epoch;
    if (previousTick.current === tickId) return;
    const isFirstTick = previousTick.current === null;
    previousTick.current = tickId;

    const mafsWin = [4, 5, 6, 7, 8, 9].includes(lastDigit);
    const paresWin = [2, 4, 6, 8].includes(lastDigit);
    setMafs((old) => ({ wins: old.wins + Number(mafsWin), losses: old.losses + Number(!mafsWin), last: mafsWin ? 'WIN' : 'LOSS' }));
    setPares((old) => ({ wins: old.wins + Number(paresWin), losses: old.losses + Number(!paresWin), last: paresWin ? 'WIN' : 'LOSS' }));

    // A signal observed on the previous tick is acted on only at the next tick.
    // The first tick after page load/start only primes the detector.
    const signalsToExecute = isFirstTick ? [] : pendingSignal.current;
    pendingSignal.current = [ ...(mafsWin ? ['mafs' as const] : []), ...(paresWin ? ['pares' as const] : []) ];

    if (!running || signalsToExecute.length === 0 || busy.current) return;
    if (!isConnected || !isAuthenticated) {
      setStatus('Entrada pendente não executada: liga a conta Deriv.');
      return;
    }

    busy.current = true;
    setStatus(`A enviar ${signalsToExecute.length} entrada(s) automática(s)…`);
    void (async () => {
      const results: boolean[] = [];
      for (const signal of signalsToExecute) {
        if (!runningRef.current) break;
        const execute = signal === 'mafs' ? autoBuyMafs : autoBuyPares;
        results.push(await execute());
      }
      setStatus(results.every(Boolean) ? `Entradas enviadas: ${signalsToExecute.join(' + ')}.` : 'Uma ou mais entradas não foram enviadas: proposta indisponível ou compra em curso.');
    })()
      .catch(() => setStatus('Falha ao enviar a entrada. Verifica a ligação e o saldo.'))
      .finally(() => { busy.current = false; });
  }, [currentTick, lastDigit, running, isConnected, isAuthenticated, isDemoAccount, autoBuyMafs, autoBuyPares]);

  useEffect(() => {
    runningRef.current = running;
    if (!running) pendingSignal.current = [];
  }, [running]);

  const start = () => {
    if (disabled) return;
    if (!isConnected || !isAuthenticated) {
      setStatus('Liga a tua conta Deriv antes de iniciar.');
      return;
    }
    if (!isDemoAccount) {
      setStatus('Por segurança, os robôs automáticos só podem ser iniciados numa conta de demonstração.');
      return;
    }
    pendingSignal.current = [];
    previousTick.current = currentTick?.epoch ?? null;
    runningRef.current = true;
    setRunning(true);
    setStatus('Robôs ativos: à espera de um sinal e do próximo tick.');
  };

  const stop = () => {
    runningRef.current = false;
    setRunning(false);
    pendingSignal.current = [];
    setStatus('Robôs parados. Não serão abertas novas entradas.');
  };

  return (
    <section className="space-y-3">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div><h2 className="text-lg font-semibold">Robôs de dígitos</h2><p className="text-xs text-muted-foreground">Os sinais são analisados em tempo real. As entradas automáticas só são permitidas após clicar em Iniciar Robô.</p></div>
        <div className="flex gap-2">
          <Button onClick={start} disabled={running || disabled || !isConnected || !isAuthenticated || !isDemoAccount} className="gap-2"><Play className="h-4 w-4" />Iniciar robô</Button>
          <Button onClick={stop} disabled={!running} variant="outline" className="gap-2"><Square className="h-4 w-4" />Parar robô</Button>
        </div>
      </div>
      <p className="text-xs text-muted-foreground" role="status">Estado: <span className="font-medium text-foreground">{running ? 'EM EXECUÇÃO' : 'DESLIGADO'}</span> — {status}</p>
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
        <RobotCard name="Mafs" description="Contrato Dígito acima de 3; sinal do bot nos dígitos 4–9." digits={[4, 5, 6, 7, 8, 9]} lastDigit={lastDigit} result={mafs} />
        <RobotCard name="Pares" description="Contrato Dígito par; sinal do bot nos dígitos 2, 4, 6 e 8." digits={[2, 4, 6, 8]} lastDigit={lastDigit} result={pares} />
      </div>
      <p className="text-xs text-muted-foreground">Cada entrada usa o valor definido no campo de aposta. Os sinais não garantem lucro. Testa primeiro numa conta de demonstração.</p>
    </section>
  );
}
