'use client';

import { Localize } from '@deriv-com/translations';
import { cn } from '@/lib/utils';
import type { DigitStats } from '../lib/types';

interface DigitStatsBarProps { digitStats: DigitStats; selectedDigit: number; onDigitSelect: (digit: number) => void; }

export function DigitStatsBar({ digitStats, selectedDigit, onDigitSelect }: DigitStatsBarProps) {
  const maxPct = Math.max(...digitStats.percentages, 1);
  return <div className="flex h-full min-h-0 flex-col"><div className="mb-3 flex items-center justify-between gap-2"><span className="text-xs sm:text-sm text-muted-foreground"><Localize i18n_default_text="Last digit prediction" /></span><span className="text-xs text-muted-foreground">{digitStats.totalTicks} ticks</span></div><div className="flex h-52 items-end gap-1 border-b border-border px-1 sm:h-60 sm:gap-2">{digitStats.percentages.map((pct, digit) => { const selected = digit === selectedDigit; const height = digitStats.totalTicks > 0 ? Math.max(3, (pct / maxPct) * 100) : 3; const color = digit === 3 || digit >= 6 ? 'bg-red-500' : digit === 1 || digit === 4 || digit === 5 ? 'bg-teal-500' : 'bg-slate-400'; return <button key={digit} type="button" onClick={() => onDigitSelect(digit)} aria-label={`Selecionar dígito ${digit}: ${pct.toFixed(1)}%`} className="group flex h-full min-w-0 flex-1 flex-col items-center justify-end gap-1 outline-none"><span className={cn('text-[10px] font-semibold sm:text-xs', selected ? 'text-primary' : 'text-muted-foreground')}>{pct.toFixed(0)}%</span><span className={cn('w-full max-w-12 rounded-t-md transition-all', color, selected && 'ring-2 ring-primary ring-offset-2 ring-offset-card')} style={{ height: `${height}%`, opacity: selected ? 1 : 0.82 }} /><span className={cn('pb-2 text-xs font-semibold sm:text-sm', selected ? 'text-primary' : 'text-muted-foreground')}>{digit}</span></button>; })}</div></div>;
}
